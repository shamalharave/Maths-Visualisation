let points = [];
let totalPoints = 15;
let z = 50;
let w = 320;//change w and h to 200 by 200 for faster load times
let h = 180;
let saveBtn

function setup() {
  createCanvas(w, h);
  background(255);
  pixelDensity(1); //need this for high density displays!
  for (let i = 0; i < totalPoints; i++) {
    points[i] = createVector(random(width), random(height), random(0, 400));
  }
    saveBtn=createButton('save')
  saveBtn.mousePressed(saveImage)
}

function draw() {
  loadPixels();
  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      let distances = [];
      for (let i of points) {
        let d = dist(x, y, z, i.x, i.y, i.z);
        distances.push(d);
      }

      let n = 0;
      let sortedDistances = sort(distances);
      r = map(sortedDistances[n], 0, w, 0, 255);
      g = map(sortedDistances[n + 1], 0, w / 2, 255, 0);
      b = map(sortedDistances[n + 2], 0, w * 2, 255, 0);

      let index = (x + y * width) * 4;
      pixels[index + 0] = r;
      pixels[index + 1] = g;
      pixels[index + 2] = b;
      pixels[index + 3] = 255;
    }
  }

  z++;
  if (z > height) {
    z = 0;
  }
  updatePixels();

  //   following code draws the points (nuclei)
  //   for (let i of points){
  //     noStroke()
  //     fill(0,255,0)
  //     ellipse(i.x,i.y,4)

  //   }

  noLoop();
}

function saveImage(){
  save('PNFlowField.png')
}
